% Experiment 2: Reflection from a surface

% Extract microphone pressure data for R = 1.0
data = guidata(gcf);
p_R1 = data.pmic;

% Plot the pressure at the five microphones
figure;
plot(1:500, p_R1(:,1:500).');

xlabel('Time step');
ylabel('Pressure');
title('Ground reflection, R = 1.0');
legend('Mic 1', 'Mic 2', 'Mic 3', 'Mic 4', 'Mic 5');
grid on;
xlim([1 500]);

%% Reflection factor R = 0.5

% After changing the ground reflection factor to R = 0.5,
% run the simulation and extract the microphone data.
data = guidata(gcf);
p_R05 = data.pmic;

% Plot the pressure at the five microphones
figure;
plot(1:500, p_R05(:,1:500).');

xlabel('Time step');
ylabel('Pressure');
title('Ground reflection, R = 0.5');
legend('Mic 1', 'Mic 2', 'Mic 3', 'Mic 4', 'Mic 5');
grid on;
xlim([1 500]);