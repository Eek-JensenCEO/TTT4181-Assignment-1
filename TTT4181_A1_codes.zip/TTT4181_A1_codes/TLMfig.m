function varargout = tlmfig(varargin)
% TLMFIG Application M-file for tlmfig.fig
%    FIG = TLMFIG launch tlmfig GUI.
%    TLMFIG('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.5 10-Feb-2004 15:40:31

if nargin == 0  % LAUNCH GUI
    
    fig = openfig(mfilename,'reuse');
        
    % Generate a structure of handles to pass to callbacks, and store it. 
    handles = guihandles(fig);
    guidata(fig, handles);
    
    % Sets global variables
    data=guidata(fig);
    
    data.tlm_res=200;
    data.geometri=zeros(data.tlm_res,data.tlm_res);
    
    guidata(fig,data)
    
    if nargout > 0
        varargout{1} = fig;
    end
    
elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK
    
    try
        [varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
    catch
        disp(lasterr);
    end
    
end


%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.




% --------------------------------------------------------------------
function varargout = intaxes_ButtondownFcn(h, eventdata, handles, varargin)
% Stub for ButtondownFcn of the axes handles.intaxes.




% --------------------------------------------------------------------
function varargout = intaxes_CreateFcn(h, eventdata, handles, varargin)
% Stub for CreateFcn of the axes handles.intaxes.








% --------------------------------------------------------------------
function varargout = start_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.start.

set(gca,'Userdata',1)
data=guidata(h);
TMAX=abs(str2num(get(findobj('tag','stepnumber'),'string')))+1;
N=data.tlm_res;
data.kilde=[];


%Resets the stop button
set(findobj('tag','stopTLM'),'value',0); 


%Defines time step
c0=340.*sqrt(2); % speed of sound defined for the transmission lines
delta_x=0.1; % length of unit cell
delta_t=delta_x/c0; % length of unit time step






%%%%%%Definer den store geometrimatrisen%%%%%%%%%%%%%%%%

geoN=(zeros(N));

%Langs kanten (siste steg)
geoN(1,:)=-20;
geoN(N,:)=-40;
geoN(:,1)=-30;
geoN(:,N)=-50;

geoN(1,1)=-3;
geoN(N,1)=-6;
geoN(1,N)=-8;
geoN(N,N)=-11;





%microphone positions
mic=find(data.geometri>=100&data.geometri<200);
[cmx cmy]=find(data.geometri>=200&data.geometri<400);
cmi=find(data.geometri>=200&data.geometri<400);
[cmxz cmyz]=find(data.geometri>=300&data.geometri<400);
[cmxc cmyc]=find(data.geometri>=400&data.geometri<500);
p_dir=zeros(length(cmx),1);

%Remove microphone info from geometri
geometri2=(rem(real(data.geometri),100));


%%%%%%%%%%Sources
sinuskilde=find(geometri2>=12&geometri2<=14);
gausskilde=find(geometri2>=15&geometri2<=17);
deltakilde=find(geometri2>=18&geometri2<=20);
stepkilde=find(geometri2>=21&geometri2<=23);
noisekilde=find(geometri2>=24&geometri2<=26);

levels=(rem(geometri2,3)-1);
NCPWvar=(find(imag(data.geometri)==0));
NCPWnotvar=(find(imag(data.geometri)));
Lvar=(find(geometri2==13|geometri2==16|geometri2==19|geometri2==22|geometri2==25));


Fmat=(geometri2*0);


Fmat(NCPWnotvar)=c0./(sqrt(1)*abs(imag(data.geometri(NCPWnotvar)))*delta_x); % the source frequency (if needed)




%%%%%%%%%%%
%%%%%%%%%%%
Rmat=(geometri2*0);
%noenher=find(imag(data.geometri))
vegger=find(real(geometri2)<10&real(geometri2)>0.5);
Rmat(vegger)=i*imag(data.geometri(vegger))+real(geometri2(vegger))-2;
Rvar=find(Rmat==2);

Rmat(vegger)=(Rmat(vegger)+1-sqrt(2)*(1-Rmat(vegger)))./(1+Rmat(vegger)+sqrt(2)*(1-Rmat(vegger)));
%vegg=find(imag(Rmat)|(Rmat<0.5&Rmat~=0));
%rv=Rmat(vegg(1))
%Rmat(vegger)
%Rnumber=rem(geometri2,1)*2/0.99-1;

geoN(vegger)=-150;

%geometri (ingen addisjon med kant)

case15=find(geoN==-150);




%dftemp=(zeros(N));
dftemp(2:N,:)=(diff(geoN));
xv_neg=find(dftemp==150);
xv_pos=find(dftemp==-150);

dftemp=(diff(geoN')');
yh_neg=find(dftemp==150);
xh_pos=find(dftemp==-150);

case1=xv_neg;
case2=yh_neg+N;
case4=xv_pos-1;
case7=xh_pos;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TLM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Initialize
AE=(zeros(N,N));
AN=(zeros(N,N));
AW=(zeros(N,N));
AS=(zeros(N,N));

AER=(zeros(N,N));
ANR=(zeros(N,N));
AWR=(zeros(N,N));
ASR=(zeros(N,N));


%%%%%%%cases%%%%%%%%%%%%%%%%%%%%5

casek1=find(geoN==-20);%\
casek7=find(geoN==-50);%|
casek4=find(geoN==-40);%|  Kanter
casek2=find(geoN==-30);%/
casek6=find(geoN==-6);  %
casek11=find(geoN==-11);%
casek8=find(geoN==-8);  %  Hj�rner
casek3=find(geoN==-3);  %

case0=find(geoN>=0);
%case1=find(geoN==1);
%case7=find(geoN==7);
%case4=find(geoN==4);
%case2=find(geoN==2);
%case6=find(geoN==6);
%case11=find(geoN==11);
%case8=find(geoN==8);
%case3=find(geoN==3);



Rk=(1-sqrt(2))/(1+sqrt(2));

%%%%Definer egen colormap
CN=2^8;
cmp=ones(3*CN+1,3);
cmp(1:CN,1)=linspace(0,1,CN)';
cmp(1:CN,2)=linspace(0,1,CN)';
cmp(CN+1:2*CN+1,3)=linspace(1,0,CN+1)';
cmp(CN+1:2*CN+1,2)=linspace(1,0,CN+1)';
%%%%%add black
cmp(2*CN+2:3*CN,2:3)=zeros(CN-1,2);
cmp(3*CN+1,1:3)=[0 0 0];


%%%%%%%%%%%%%%%%%%%%%%%%% Start time loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kt=0;
t_loop=0;
F=moviein(TMAX);
clear pmic

while (get(gca,'Userdata')==1)&(kt<TMAX-1)
    
    kt=kt+1;
    t_loop=t_loop+delta_t;
    ncpw=(get(findobj('tag','NCPWslider'),'value')); % number of cells per wavelength
    lambda=ncpw*delta_x; % the source wavelength (if needed)
    Fmat(NCPWvar)=c0/(sqrt(1)*lambda); % the source frequency (if needed)
    
    levels(Lvar)=(get(findobj('tag','Lslider'),'value'));
    
    Rmat(Rvar)=(get(findobj('tag','Rslider'),'value'));
    %%%%Moving source test
    
    %sinuskilde=round(180*80+15+0.005*kt^2);
    
    %%%%%%%%%%%%%%%%%%%%%
    %arg=exp(-pi*pi*(Fmat(gausskilde)*t_loop-1).*(f*t_loop-1));
%gauss_source=1.*exp(arg);
    
    
 
    
        AE(gausskilde)=exp(-pi*pi*(Fmat(gausskilde)*t_loop-1).*(Fmat(gausskilde)*t_loop-1)).*levels(gausskilde)+AE(gausskilde);
        AW(gausskilde)=exp(-pi*pi*(Fmat(gausskilde)*t_loop-1).*(Fmat(gausskilde)*t_loop-1)).*levels(gausskilde)+AW(gausskilde);
        AS(gausskilde)=exp(-pi*pi*(Fmat(gausskilde)*t_loop-1).*(Fmat(gausskilde)*t_loop-1)).*levels(gausskilde)+AS(gausskilde);
        AN(gausskilde)=exp(-pi*pi*(Fmat(gausskilde)*t_loop-1).*(Fmat(gausskilde)*t_loop-1)).*levels(gausskilde)+AN(gausskilde);
    
    AE(sinuskilde)=exp(i*(2*pi*Fmat(sinuskilde)*t_loop+pi/2)).*levels(sinuskilde)+AE(sinuskilde);
    AW(sinuskilde)=exp(i*(2*pi*Fmat(sinuskilde)*t_loop+pi/2)).*levels(sinuskilde)+AW(sinuskilde);
    AS(sinuskilde)=exp(i*(2*pi*Fmat(sinuskilde)*t_loop+pi/2)).*levels(sinuskilde)+AS(sinuskilde);
    AN(sinuskilde)=exp(i*(2*pi*Fmat(sinuskilde)*t_loop+pi/2)).*levels(sinuskilde)+AN(sinuskilde);
    if kt==1
        AE(deltakilde)=1.*levels(deltakilde)+AE(deltakilde);
        AW(deltakilde)=1.*levels(deltakilde)+AW(deltakilde);
        AS(deltakilde)=1.*levels(deltakilde)+AS(deltakilde);
        AN(deltakilde)=1.*levels(deltakilde)+AN(deltakilde);
    end
    AE(stepkilde)=1.*levels(stepkilde);
    AW(stepkilde)=1.*levels(stepkilde);
    AS(stepkilde)=1.*levels(stepkilde);
    AN(stepkilde)=1.*levels(stepkilde);
    
    nkt=randn;
    AE(noisekilde)=nkt.*levels(noisekilde);
    AW(noisekilde)=nkt.*levels(noisekilde);
    AS(noisekilde)=nkt.*levels(noisekilde);
    AN(noisekilde)=nkt.*levels(noisekilde);
    
    
    
    
    
    
    %    end
    %end
    
    % Calculate new values for all the nodes
    ANR=0.5*(+AE-AN+AW+AS);
    AER=0.5*(-AE+AN+AW+AS);
    AWR=0.5*(+AE+AN-AW+AS);
    ASR=0.5*(+AE+AN+AW-AS);
    
    
    %%For special conditions at screen surfaces
    %R=str2num(get(findobj('tag','R'),'string'));
    
    %Fritt felt
    AE(case0)=AWR(case0+N);
    AN(case0)=ASR(case0+1);
    AW(case0)=AER(case0-N);
    AS(case0)=ANR(case0-1);
    
    
    %%%%%%%%%%Langs kanten, med Rnumber=-0.17
    
    %-Langs kant Vegg i s�r
    AE(casek1)=AWR(casek1+N);
    AW(casek1)=AER(casek1-N);
    AN(casek1)=ASR(casek1+1);
    AS(casek1)=Rk*ASR(casek1);
    
    %-Langs kant Vegg i �st
    AE(casek7)=Rk*AER(casek7);
    AW(casek7)=AER(casek7-N);
    AN(casek7)=ASR(casek7+1);
    AS(casek7)=ANR(casek7-1);
    
    %-Langs kant Vegg i nord
    AE(casek4)=AWR(casek4+N);
    AW(casek4)=AER(casek4-N);
    AN(casek4)=Rk*ANR(casek4);
    AS(casek4)=ANR(casek4-1);
    
    %-Langs kant Vegg i vest
    AE(casek2)=AWR(casek2+N);
    AW(casek2)=Rk*AWR(casek2);
    AN(casek2)=ASR(casek2+1);
    AS(casek2)=ANR(casek2-1);
    
    %-Langs kant Hj�rne Nord-vest
    AE(casek6)=AWR(casek6+N);
    AW(casek6)=Rk*AWR(casek6);
    AN(casek6)=Rk*ANR(casek6);
    AS(casek6)=ANR(casek6-1);
    
    %-Langs kant Hj�rne Nord �st
    AE(casek11)=Rk*AER(casek11);
    AW(casek11)=AER(casek11-N);
    AN(casek11)=Rk*ANR(casek11);
    AS(casek11)=ANR(casek11-1);
    
    %-Langs kant Hj�rne s�r �st
    AE(casek8)=Rk*AER(casek8);
    AW(casek8)=AER(casek8-N);
    AN(casek8)=ASR(casek8+1);
    AS(casek8)=Rk*ASR(casek8);
    
    %-Langs kant hj�rne s�r vest
    AE(casek3)=AWR(casek3+N);
    AW(casek3)=Rk*AWR(casek3);
    AN(casek3)=ASR(casek3+1);
    AS(casek3)=Rk*ASR(casek3);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
   
    
    %Vegg i s�r
    AS(case1)=ASR(case1).*Rmat(case1-1);
    
    %Vegg i �st
    AE(case7)=AER(case7).*Rmat(case7+N);
    
    %Vegg i nord
    AN(case4)=ANR(case4).*Rmat(case4+1);
    
    %Vegg i vest
    AW(case2)=AWR(case2).*Rmat(case2-N);
    
    
    % Total pressure at each node
    Ptot=(0.5*(AER+ANR+AWR+ASR));
    Ptot(case15)=0;
    

    %gaussian filter
    if get(findobj('tag','sp_filter'),'value')
        mu=get(findobj('tag','sp_filter_value'),'value');
        e=exp(1);
        f1=e^-mu;
        f2=e^(-2*mu);
        Ptot(case0)=Ptot(case0)+f1*Ptot(case0+N)+f1*Ptot(case0+1)+f1*Ptot(case0-N)+f1*Ptot(case0-1)+f2*Ptot(case0-N-1)+f2*Ptot(case0-N+1)+f2*Ptot(case0+N+1)+f2*Ptot(case0+N-1);
    end
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%
    %collect values for directional plot
    if ~isempty(cmx)
        
        size(Ptot(cmi).^2);
        p_dir=p_dir+(abs(Ptot(cmi)).^2);
    end
    %%%%%%%%%%%%%%
    if ~isempty(mic)
        N_mic=length(mic);
        % Here you can define microphones
        pmic(:,kt)=Ptot(mic);
        
        
        %  set(findobj('tag','disp_SPL'),'string',['Lp: ',num2str(spl+100),' dB     Leq: ',num2str(Leq+100),' dB   Step: ',num2str(kt)]);
        set(findobj('tag','disp_SPL'),'string',['  Step: ',num2str(kt)]);    
    else
        set(findobj('tag','disp_SPL'),'string',['  Step: ',num2str(kt)]);
    end
    
    %For surface
    if get(findobj('tag','autoscale'),'value')
        maxC=max(max(abs(Ptot)));
        
        set(findobj('tag','c_lim'),'value',min(-maxC,-get(findobj('tag','c_lim'),'Min')));
        
    else
        maxC=-get(findobj('tag','c_lim'),'value');
    end
    
    
    
    Ptot(case15)=2*max(max(abs(Ptot)));
    % to plot values 
    
    
    temp=zeros(N+1);
    temp(1:N,1:N)=Ptot;
    
    if get(findobj('tag','V_re'),'value')
        surf(real(temp),'linestyle','none');
    else 
        surf(abs(temp),'linestyle','none');
    end
    
    colormap(cmp)
    view(0,90)
    
    caxis([-maxC,2*maxC]);
    set(gca,'xlim',[1 N+1]);
    set(gca,'ylim',[1 N+1]);
    
    
    %%%%%%%3d-plott
    %view(45,45);
    %axis([1 N 1 N -0.4 0.4]);
    
    
    F(:,1) = getframe;
end    % End of time loop
%movie(F)

if ~isempty(mic)
    
    
    figure(2)
    if N_mic==1
        
        plot(real(pmic));
    else
        waterfall(real(pmic))
    end    
    
    data.pmic=pmic;
end
guidata(h,data)
size(cmyc);
if ~isempty(cmx)
    theta=angle(cmxc-cmx + i*(cmyc-cmy))-angle(cmxc-cmxz + i*(cmyc-cmyz));
    size(theta);
    %u=randn(1,size(theta))'+12; for testing?
    
    [ts s]=sort(theta);
    figure(3), polar(ts,p_dir(s))
    
    
end %OF MAIN TLM LOOP FUNCTION

%-----------------------------------------------------------------------
function varargout = tlm_res_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.N_res.
data=guidata(h);
tlm_res=data.tlm_res;
if isempty(str2num(get(gco,'string')))
    N=100;
    disp('ugyldig inntasting, oppl�ysing satt til 100');
    
else
    N=(str2num(get(gco,'string')));
    N=min(N,300);
    N=max(N,5);
end
set(gco,'string',num2str(N));

temp=(zeros(N));
%%%%
if N>=tlm_res
    for geocases=1:10;
        [r c]=find(round(real(data.geometri))==geocases);
        for ct=1:length(r);
            temp(floor((r(ct)-1)*(N/tlm_res))+1:floor((N/tlm_res)*(r(ct))),...
                floor((c(ct)-1)*(N/tlm_res))+1:floor((N/tlm_res)*(c(ct))))=data.geometri(r(ct),c(ct));
        end
    end
    %%%%
    
end


tlmupdate(temp)


data.geometri=temp;
data.tlm_res=N;
guidata(h,data)


% --------------------------------------------------------------------


% --------------------------------------------------------------------
function varargout = velg_linje_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.velg_linje.
data=guidata(h);
varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end
tlmupdate(data.geometri)

p1=floor(ginput(1));

x1=p1(1);
y1=p1(2);

data.geometri(y1,x1)=2+R;

tlmupdate(data.geometri)

p2=floor(ginput(1));
x2=p2(1);
y2=p2(2);




data.geometri(floor(y1),floor(x1))=2+R;
if ~((x1==x2)&(y1==y2))
    dx=x2-x1;
    dy=y2-y1;
    
    if abs(dx)>abs(dy)
        a=dy/dx;
        for punkt=sign(dx):sign(dx):dx
            data.geometri(round(a*punkt+y1),punkt+x1)=2+R;
        end
    else
        a=dx/dy;
        for punkt=sign(dy):sign(dy):dy
            data.geometri(punkt+y1,round(a*punkt+x1))=2+R;
        end
        
    end
end





tlmupdate(data.geometri)

guidata(h,data)




% --------------------------------------------------------------------

% --------------------------------------------------------------------
function varargout = tegn_rektangel_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.tegn_rektangel.
data=guidata(h);

varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end

tlmupdate(data.geometri)


p1=floor(ginput(1));

x(1)=p1(1);
y(1)=p1(2);

data.geometri(y(1),x(1))=2+R;

tlmupdate(data.geometri)

p2=floor(ginput(1));
x(2)=p2(1);
y(2)=p2(2);

x=sort(x);
y=sort(y);

data.geometri(y(1),x(1):x(2))=2+R;
data.geometri(y(1):y(2),x(2))=2+R;
data.geometri(y(1):y(2),x(1))=2+R;
data.geometri(y(2),x(1):x(2))=2+R;





tlmupdate(data.geometri)

guidata(h,data)




% --------------------------------------------------------------------
function varargout = slett_rektangel_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.slett_rektangel.
data=guidata(h);


tlmupdate(data.geometri)

p1=floor(ginput(1));

x(1)=p1(1);
y(1)=p1(2);

data.geometri(y(1),x(1))=0;
temp=zeros(data.tlm_res+1);
temp(1:data.tlm_res,1:data.tlm_res)=round(abs(data.geometri));
surf(temp,'linestyle','none');

view(0,90)
caxis([0 3]);
cmap=[1 1 1
    0 0 0
    0 0 1
    0 1 0];


colormap(cmap)

p2=floor(ginput(1));
x(2)=p2(1);
y(2)=p2(2);

x=sort(x);
y=sort(y);
data.geometri(y(1):y(2),x(1):x(2))=0;
tlmupdate(data.geometri)

guidata(h,data)

% --------------------------------------------------------------------
function varargout = tegn_sirkel_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.tegn_sirkel.
data=guidata(h);
varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end


tlmupdate(data.geometri)


p1=floor(ginput(1));

xs=p1(1);
ys=p1(2);

p2=floor(ginput(1));
xr=p2(1);
yr=p2(2);

r=round(sqrt((xr-xs)^2+(yr-ys)^2));


for x=max(1,xs-r):min(data.tlm_res,xs+r)
    y=round(sqrt(r^2-(x-xs)^2)+ys);
    if (y>0)&(y<=data.tlm_res)
        data.geometri(y,x)=2+R;
    end
    y=round(-sqrt(r^2-(x-xs)^2)+ys);
    if (y>0)&(y<=data.tlm_res)
        data.geometri(y,x)=2+R;
    end
    
end

for y=max(1,ys-r):min(data.tlm_res,ys+r)
    x=round(sqrt(r^2-(y-ys)^2)+xs);
    if (x>0)&(x<=data.tlm_res)
        data.geometri(y,x)=2+R;
    end
    x=round(-sqrt(r^2-(y-ys)^2)+xs);
    if (x>0)&(x<=data.tlm_res)
        data.geometri(y,x)=2+R;
    end
    
end


tlmupdate(data.geometri)

guidata(h,data)




% --------------------------------------------------------------------
%function varargout = steps_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.steps.
%if isempty(str2num(get(gco,'string')))
%   N=300;


%else
%   N=(str2num(get(gco,'string')));

%end
%set(gco,'string',num2str(N));



% --------------------------------------------------------------------
function varargout = linjekilde_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.linjekilde.
%disp('linjekilde Callback not implemented yet.')
data=guidata(h);


varL=get(findobj('tag','Lbox'),'value');
if varL
    level=0;
else
    level=str2num(get(findobj('tag','Lnumber'),'string'));
end
varNCPW=get(findobj('tag','NCPWbox'),'value');
if varNCPW
    NCPW=0;
else
    NCPW=str2num(get(findobj('tag','NCPWnumber'),'string'));
end

kildetype=get(findobj('tag','velg_kilde'),'value')*3+10+level+i*NCPW;


tlmupdate(data.geometri)

p1=floor(ginput(1));

x1=p1(1);
y1=p1(2);

data.geometri(y1,x1)=kildetype;

tlmupdate(data.geometri)

p2=floor(ginput(1));
x2=p2(1);
y2=p2(2);


data.geometri(floor(y1),floor(x1))=kildetype;
if ~((x1==x2)&(y1==y2))
    dx=x2-x1;
    dy=y2-y1;
    
    if abs(dx)>abs(dy)
        a=dy/dx;
        for punkt=sign(dx):sign(dx):dx
            data.geometri(round(a*punkt+y1),punkt+x1)=kildetype;
        end
    else
        a=dx/dy;
        for punkt=sign(dy):sign(dy):dy
            data.geometri(punkt+y1,round(a*punkt+x1))=kildetype;
        end
        
    end
end





tlmupdate(data.geometri)

guidata(h,data)





% --------------------------------------------------------------------
function varargout = edit4_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit4.
%disp('edit4 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = edit5_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit5.
%disp('edit5 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = edit6_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit6.
%disp('edit6 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = edit7_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit7.
%disp('edit7 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = edit8_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit8.
%disp('edit8 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = edit9_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit9.
%disp('edit9 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = c_lim_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.c_lim.
%disp('c_lim Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = put_mic_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.put_mic.
data=guidata(h);

tlmupdate(data.geometri)

N_mic=str2num(get(findobj('tag','mic_number'),'string'));
pre=find(data.geometri>100);
data.geometri(pre)=rem(real(data.geometri(pre)),100)+i*imag(data.geometri(pre));
%

p1=floor(ginput(1));

x1=p1(1);
y1=p1(2);
data.geometri(y1,x1)=data.geometri(y1,x1)+100;
tlmupdate(data.geometri)
if N_mic>1
    %%%%%%%%%%Mic array%%%%%%%%%%
    data.geometrirem=rem(real(data.geometri),100);
    data.geometri=data.geometrirem+i*imag(data.geometri);
    data.geometri(y1,x1)=data.geometri(y1,x1)+100;
    p2=floor(ginput(1));
    x2=p2(1);
    y2=p2(2);
    
    
    data.geometri(floor(y2),floor(x2))=data.geometri(floor(y2),floor(x2))+100;
    if N_mic>2
        if ~((x1==x2)&(y1==y2))
            dx=(x2-x1)/(N_mic-1);
            dy=(y2-y1)/(N_mic-1);
            
            if abs(dx)>abs(dy)
                a=dy/dx;
                for punkt=1:N_mic-2
                    data.geometri(floor(a*punkt*dx+y1),floor(punkt*dx+x1))=100+data.geometrirem(floor(a*punkt*dx+y1),floor(punkt*dx+x1));
                end
            else
                a=dx/dy;
                for punkt=1:N_mic-2
                    data.geometri(floor(punkt*dy+y1),floor(a*punkt*dy+x1))=100+data.geometrirem(floor(punkt*dy+y1),floor(a*punkt*dy+x1));
                end
            end
        end
    end
    tlmupdate(data.geometri)
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
guidata(h,data)


%%%%%%%%%%%%%%%%%


% --------------------------------------------------------------------
function varargout = autoscale_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.autoscale.
%disp('autoscale Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = Rnumber_Callback(h, eventdata, handles, varargin)


if isempty(str2num(get(gco,'string')))
    R=1;
else
    R=(str2num(get(gco,'string')));
    
    R=min(abs(R),1)*sign(R);
end
set(gco,'string',num2str(R));



% --------------------------------------------------------------------
function varargout = stopTLM_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.stopTLM.
%disp('stopTLM Callback wrongly implemented yet.')
%break
set(gca,'Userdata',-1);

% --------------------------------------------------------------------
function varargout = save_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.steps.
%[filename,pathname]=uiputfile('*.mat','Save configuration');
data=guidata(h);
uisave

% --------------------------------------------------------------------
function varargout = open_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.steps.
%[filename,pathname]=uiputfile('*.mat','Save configuration');
%data=guidata(h);
uiopen
if exist('data')
    if isfield(data,'geometri')
        guidata(gcf,data);
        tlmupdate(data.geometri)
    end
else
    disp('Not a valid .mat file for this figure')
end


% --------------------------------------------------------------------
function varargout = mic_number_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.mic_number.
if isempty(str2num(get(gco,'string')))
    N=1;
else
    N=(str2num(get(gco,'string')));
    
    N=max(N,1);
end
set(gco,'string',num2str(N));


% --------------------------------------------------------------------
function varargout = del_sources_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.del_sources.
data=guidata(h);
data.geometri(find(data.geometri>10&data.geometri<100))=0;
tlmupdate(data.geometri)
guidata(h,data)



% --------------------------------------------------------------------
function varargout = Lslider_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.Lslider.
level=get(gco,'value');
set(findobj('tag','Lnumber'),'string',num2str(level));


% --------------------------------------------------------------------
function varargout = sp_filter_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.sp_filter.
%disp('sp_filter Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = sp_filter_value_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.sp_filter_value.
%disp('sp_filter_value Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = NCPWslider_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.NCPWslider.
level=get(gco,'value');
set(findobj('tag','NCPWnumber'),'string',num2str(level));

% --------------------------------------------------------------------
function varargout = circmic_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.circmic.
% Stub for Callback of the uicontrol handles.tegn_sirkel.
data=guidata(h);
data.geometri=rem(real(data.geometri),100);

tlmupdate(data.geometri)


p1=floor(ginput(1));

xs=p1(1);
ys=p1(2);

p2=floor(ginput(1));
xr=p2(1);
yr=p2(2);

r=round(sqrt((xr-xs)^2+(yr-ys)^2));


for x=max(1,xs-r):min(data.tlm_res,xs+r)
    y=round(sqrt(r^2-(x-xs)^2)+ys);
    if (y>0)&(y<=data.tlm_res)
        data.geometri(y,x)=rem(data.geometri(y,x),100)+200;
    end
    y=round(-sqrt(r^2-(x-xs)^2)+ys);
    if (y>0)&(y<=data.tlm_res)
        data.geometri(y,x)=rem(data.geometri(y,x),100)+200;
    end
    
end

for y=max(1,ys-r):min(data.tlm_res,ys+r)
    x=round(sqrt(r^2-(y-ys)^2)+xs);
    if (x>0)&(x<=data.tlm_res)
        data.geometri(y,x)=rem(data.geometri(y,x),100)+200;
    end
    x=round(-sqrt(r^2-(y-ys)^2)+xs);
    if (x>0)&(x<=data.tlm_res)
        data.geometri(y,x)=rem(data.geometri(y,x),100)+200;
    end
    
end
data.geometri(ys,xs)=rem(data.geometri(ys,xs),100)+400;
data.geometri(yr,xr)=rem(data.geometri(yr,xr),100)+300;

tlmupdate(data.geometri)

guidata(h,data);

% --------------------------------------------------------------------
function varargout = velgpunkt_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.velgpunkt.

data=guidata(h);
varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end

tlmupdate(data.geometri)

[x,y]=ginput(1);
data.geometri(floor(y),floor(x))=~data.geometri(floor(y),floor(x))*(2+R);

tlmupdate(data.geometri)

guidata(h,data)


% --------------------------------------------------------------------
function varargout = reset_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.reset.
data=guidata(h);
data.geometri=zeros(data.tlm_res);
tlmupdate(data.geometri)
guidata(h,data);



% --------------------------------------------------------------------
function varargout = velg_kilde_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.velg_kilde.



% --------------------------------------------------------------------
function pmic = put_kilde_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.put_kilde.

%%%%%%%%%%%%%%NEW
data=guidata(h);
varL=get(findobj('tag','Lbox'),'value');
if varL
    level=0;
else
    level=str2num(get(findobj('tag','Lnumber'),'string'));
end
varNCPW=get(findobj('tag','NCPWbox'),'value');
if varNCPW
    NCPW=0;
else
    NCPW=str2num(get(findobj('tag','NCPWnumber'),'string'));
end

kildetype=get(findobj('tag','velg_kilde'),'value')*3+10+level+i*NCPW;


tlmupdate(data.geometri)

[x,y]=ginput(1);
data.geometri(floor(y),floor(x))=kildetype*~data.geometri(floor(y),floor(x));

tlmupdate(data.geometri)

guidata(h,data)


%%%%%%%%%%%%%%%%%




% --------------------------------------------------------------------
function varargout = V_re_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.V_re.
set(findobj('tag','V_abs'),'value',0);
set(gco,'value',1);

% --------------------------------------------------------------------
function varargout = V_abs_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.V_abs.
set(findobj('tag','V_re'),'value',0);
set(gco,'value',1);

% --------------------------------------------------------------------
function varargout = V_im_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.V_im.
set(findobj('tag','V_re'),'value',0);
set(findobj('tag','V_abs'),'value',0);
set(gco,'value',1);






% --------------------------------------------------------------------
function varargout = set_Z_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.set_Z.
figure
polar(1)
[x y]=ginput(1);
set(gco,'value',x+i*y)
close
R=x+i*y;
mag=abs(R)
pha=angle(R)
if pha<0
    pha=pha+2*pi;
end
R=round(100*mag*exp(i*pha))/100;

set(findobj('tag','R_tekst'),'string',['R = ' num2str(R)]);
set(findobj('tag','R'),'value',mag);
set(findobj('tag','R_imag'),'value',pha);


function tlmupdate(geomap)

res=max(size(geomap));
temp=zeros(res+1);
temp(1:res,1:res)=round(abs(geomap));



surf(temp,'linestyle','none');
caxis([0 11]);
cmap=[1 1 1
    0 0 0
    0 0 0
    0 0 0
    0 0 0
    0 0 1
    0 0 1
    0 0 1
    0 0 1
    0 0 1
    0 1 0];


colormap(cmap)
view(0,90)
set(gca,'xlim',[1 res+1]);
set(gca,'ylim',[1 res+1]);


% --- Executes during object creation, after setting all properties.
function stepnumber_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stepnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function stepnumber_Callback(hObject, eventdata, handles)
% hObject    handle to stepnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of stepnumber as text
%        str2double(get(hObject,'String')) returns contents of stepnumber as a double
if isempty(str2num(get(gco,'string')))
    N=100;
    set(gco,'string',num2str(N));
end


% --- Executes during object creation, after setting all properties.
function Rnumber_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes during object creation, after setting all properties.
function drawfunct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to drawfunct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function drawfunct_Callback(hObject, eventdata, handles)
% hObject    handle to drawfunct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of drawfunct as text
%        str2double(get(hObject,'String')) returns contents of drawfunct as a double

data=guidata(hObject);

varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end

%tlmupdate(data.geometri)
str2num(get(gco,'string'));
N=data.tlm_res;
x=1:N+1;


y=round(eval(get(gco,'string')));
if all(size(y)==[1 1])
    y=ones(1,N+1)*y;
end

for teller=1:N;
    
    dy=sign(y(teller+1)-y(teller));
    if (y(teller)>=1)&(y(teller)<=N)&(y(teller+1)>=1)&(y(teller+1)<=N)
        if dy==0
           data.geometri(y(teller),x(teller))=2+R;
        else
            data.geometri(y(teller):dy:y(teller+1)-dy,x(teller))=2+R;
        end
    elseif (y(teller)>=1)&(y(teller)<=N)
        if dy==1;
            data.geometri(y(teller):dy:N,x(teller))=2+R;
        elseif dy==-1
            data.geometri(y(teller):dy:1,x(teller))=2+R;
        end
    elseif (y(teller+1)>=1)&(y(teller+1)<=N)
        if dy==1;
            data.geometri(1:y(teller+1)-1,x(teller))=2+R;
        elseif dy==-1
            data.geometri(N:dy:y(teller+1),x(teller))=2+R;
        end
    end
end
%size(data.geometri)
%data.geometri=data.geometri(1:N-1,1:N-1);
tlmupdate(data.geometri)

guidata(hObject,data)


% --- Executes on button press in Lbox.
function Lbox_Callback(hObject, eventdata, handles)
% hObject    handle to Lbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Lbox


% --- Executes on button press in NCPWbox.
function NCPWbox_Callback(hObject, eventdata, handles)
% hObject    handle to NCPWbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of NCPWbox


% --- Executes during object creation, after setting all properties.
function Lnumber_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function Lnumber_Callback(hObject, eventdata, handles)
% hObject    handle to Lnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Lnumber as text
%        str2double(get(hObject,'String')) returns contents of Lnumber as a double
N=str2num(get(hObject,'string'));
if isempty(N)
    N=1;
end
set(hObject,'string',min([abs(N) 1])*sign(N));

% --- Executes during object creation, after setting all properties.
function NCPWnumber_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NCPWnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function NCPWnumber_Callback(hObject, eventdata, handles)
% hObject    handle to NCPWnumber (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of NCPWnumber as text
%        str2double(get(hObject,'String')) returns contents of NCPWnumber as a double
N=str2num(get(hObject,'string'));
if isempty(N)
    N=15;
end
set(hObject,'string',max([N 15]));

% --- Executes during object creation, after setting all properties.
function Rslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function Rslider_Callback(hObject, eventdata, handles)
% hObject    handle to Rslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
ht=findobj('tag','Rnumber');
v=get(hObject,'Value');
set(ht,'string',num2str(v));


% --- Executes on button press in Rbox.
function Rbox_Callback(hObject, eventdata, handles)
% hObject    handle to Rbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Rbox


% --- Executes on button press in V_abs.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to V_abs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of V_abs


% --- Executes on button press in del_mics.
function del_mics_Callback(hObject, eventdata, handles)
% hObject    handle to del_mics (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data=guidata(hObject);
data.geometri=rem(real(data.geometri),100);

tlmupdate(data.geometri)

guidata(hObject,data)


% --- Executes during object creation, after setting all properties.
function ydrawfunct_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ydrawfunct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function ydrawfunct_Callback(hObject, eventdata, handles)
% hObject    handle to ydrawfunct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ydrawfunct as text
%        str2double(get(hObject,'String')) returns contents of ydrawfunct as a double

% hObject    handle to drawfunct (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of drawfunct as text
%        str2double(get(hObject,'String')) returns contents of drawfunct as a double

data=guidata(hObject);
data.geometri=data.geometri';
varR=get(findobj('tag','Rbox'),'value');
if varR
    R=2;
else
    R=str2num(get(findobj('tag','Rnumber'),'string'));
end

%tlmupdate(data.geometri)
str2num(get(gco,'string'));
N=data.tlm_res;
y=1:N+1;

x=round(eval(get(gco,'string')));
if all(size(x)==[1 1])
    x=ones(1,N+1)*x;
end

for teller=1:N;
    if ~all(size(data.geometri)==[N N])
        teller
    end
    dx=sign(x(teller+1)-x(teller));
    if (x(teller)>=1)&(x(teller)<=N)&(x(teller+1)>=1)&(x(teller+1)<=N)
        if dx==0
           data.geometri(x(teller),y(teller))=2+R;
        else
            data.geometri(x(teller):dx:x(teller+1)-dx,y(teller))=2+R;
        end
    elseif (x(teller)>=1)&(x(teller)<=N)
        if dx==1;
            data.geometri(x(teller):dx:N,y(teller))=2+R;
        elseif dx==-1
            data.geometri(x(teller):dx:1,y(teller))=2+R;
        end
    elseif (x(teller+1)>=1)&(x(teller+1)<=N)
        if dx==1;
            data.geometri(1:x(teller+1)-1,y(teller))=2+R;
        elseif dx==-1
            data.geometri(N:dx:x(teller+1)+1,y(teller))=2+R;
        end
    end
end
%size(data.geometri)
data.geometri=data.geometri';
tlmupdate(data.geometri)

guidata(hObject,data)

