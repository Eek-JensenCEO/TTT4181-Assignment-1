% Experiment 3: Insertion loss from the noise screen
% The four pressure datasets below were saved from the corresponding
% TLMfig simulations before running this analysis.

% Calculate RMS pressure for simulations with and without the screen
rms_no_screen_15 = sqrt(mean(p_15_no_screen.^2, 2));
rms_screen_15    = sqrt(mean(p_15_screen.^2, 2));

rms_no_screen_45 = sqrt(mean(p_45_no_screen.^2, 2));
rms_screen_45    = sqrt(mean(p_45_screen.^2, 2));

% Calculate insertion loss
IL_15 = 20 * log10(rms_no_screen_15 ./ rms_screen_15);
IL_45 = 20 * log10(rms_no_screen_45 ./ rms_screen_45);

% Display the calculated insertion loss values
disp('Insertion loss for 15 cells/wavelength [dB]:')
disp(IL_15)

disp('Insertion loss for 45 cells/wavelength [dB]:')
disp(IL_45)

%% Plot insertion loss as a function of distance from the screen

% Microphone and screen positions in grid cells
microphone_x = [56 77 98 119 141];
screen_x = 52;

% Convert the distance from grid cells to metres
distance = (microphone_x - screen_x) * 0.1;

figure;
plot(distance, IL_15, '-o', 'LineWidth', 1.5);
hold on;
plot(distance, IL_45, '-o', 'LineWidth', 1.5);

xlabel('Distance from screen [m]');
ylabel('Insertion loss [dB]');
legend('15 cells/wavelength', '45 cells/wavelength', ...
    'Location', 'best');
grid on;