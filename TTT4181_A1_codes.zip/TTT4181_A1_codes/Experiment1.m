% Experiment 1: Free-field propagation

% Extract microphone pressure data from TLMfig
data = guidata(gcf);
p = data.pmic;

% Calculate RMS pressure after the initial transient
% The first 199 time steps are excluded because the signal
% has not yet reached a stable state.
p_rms = sqrt(mean(real(p(:,200:end)).^2, 2));

% Find microphone positions from the simulation geometry
[ym, xm] = find(real(data.geometri) >= 100 & ...
                real(data.geometri) < 200);
microphones = [xm ym];

% Find the source position from the simulation geometry
[ys, xs] = find(real(data.geometri) >= 12 & ...
                real(data.geometri) <= 26);
source = [xs ys];

% Calculate the distance from the source to each microphone
% The grid cell size is 0.1 m.
d = 0.1 * sqrt(sum((microphones - source).^2, 2));

% Calculate relative sound pressure level
% The first microphone is used as the reference.
Lp = 20 * log10(p_rms / p_rms(1));

% Plot relative SPL as a function of distance from the source
figure
plot(d, Lp, 'o-')
xlabel('Distance from source [m]')
ylabel('Relative sound pressure level [dB]')
grid on